/**
 * KZ WhatsApp AI Mentor Bot
 * Stack: Node.js + Express + Twilio + Claude API
 * Deploy: Koyeb (free tier)
 * Author: Kimiyyar Zahiri (@Kriptomech)
 */

const express = require('express');
const twilio = require('twilio');
const Anthropic = require('@anthropic-ai/sdk');

const app = express();
app.use(express.urlencoded({ extended: false }));
app.use(express.json());

const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

// Health check — Koyeb uses this to confirm app is live
app.get('/', (req, res) => {
  res.json({ status: 'ok', service: 'KZ WhatsApp AI Mentor Bot', version: '1.0' });
});

// Twilio WhatsApp webhook
app.post('/webhook', async (req, res) => {
  const incomingMsg = req.body.Body?.trim() || '';
  const from = req.body.From || '';

  console.log(`[KZ Bot] Message from ${from}: ${incomingMsg}`);

  try {
    const response = await client.messages.create({
      model: 'claude-haiku-4-5-20251001',
      max_tokens: 500,
      system: `You are KZ Mentor — an AI learning assistant for KZ Digital Intelligence Hub (KZDI), 
serving Arewa youth in Northern Nigeria. You teach AI literacy, Web3, digital skills, 
and entrepreneurship in simple Hausa and English. 

Rules:
- Be friendly, concise, and culturally respectful
- Use Hausa words naturally when helpful (e.g. "Sannu!", "Nagode", "Da kyau")
- Avoid Riba/Gharar/Maysir — flag if topic touches Islamic finance concerns
- Keep responses short (WhatsApp-friendly, under 300 words)
- End with an encouraging phrase`,
      messages: [{ role: 'user', content: incomingMsg }],
    });

    const reply = response.content[0]?.text || 'Nagode! Try again.';

    const twiml = new twilio.twiml.MessagingResponse();
    twiml.message(reply);

    res.type('text/xml').send(twiml.toString());
  } catch (err) {
    console.error('[KZ Bot] Error:', err.message);
    const twiml = new twilio.twiml.MessagingResponse();
    twiml.message('Server error. Aiki ne — please try again shortly.');
    res.type('text/xml').send(twiml.toString());
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`[KZ Bot] Running on port ${PORT}`);
});
