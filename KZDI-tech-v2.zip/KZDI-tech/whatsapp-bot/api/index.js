// api/index.js — Health check endpoint
export default function handler(req, res) {
  res.status(200).json({
    status: 'ok',
    service: 'KZ WhatsApp AI Mentor Bot',
    version: '1.0'
  });
}
