// api/webhook.js — Vercel Serverless Function
// Route: POST /api/webhook

const Anthropic = require('@anthropic-ai/sdk');

const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const incomingMsg = req.body?.Body?.trim() || '';
  const from = req.body?.From || '';

  console.log(`[KZ Bot] From: ${from} | Message: ${incomingMsg}`);

  try {
    const response = await client.messages.create({
      model: 'claude-haiku-4-5-20251001',
      max_tokens: 500,
      system: `You are KZ Mentor — an AI learning assistant for KZ Digital Intelligence Hub (KZDI), 
serving Arewa youth in Northern Nigeria. You teach AI literacy, Web3, digital skills, 
and entrepreneurship in simple Hausa and English.

Rules:
- Be friendly, concise, and culturally respectful
- Use Hausa words naturally when helpful (e.g. "Sannu!", "Nagode", "Da kyau")
- Avoid Riba/Gharar/Maysir — flag if topic touches Islamic finance concerns
- Keep responses short (WhatsApp-friendly, under 300 words)
- End with an encouraging phrase`,
      messages: [{ role: 'user', content: incomingMsg }],
    });

    const reply = response.content[0]?.text || 'Nagode! Please try again.';

    // Return Twilio TwiML XML
    res.setHeader('Content-Type', 'text/xml');
    res.status(200).send(`<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Message>${reply}</Message>
</Response>`);

  } catch (err) {
    console.error('[KZ Bot] Error:', err.message);
    res.setHeader('Content-Type', 'text/xml');
    res.status(200).send(`<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Message>Aiki ne — server error. Please try again shortly. Nagode!</Message>
</Response>`);
  }
}
